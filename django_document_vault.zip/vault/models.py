from django.db import models

class Document(models.Model):
    title = models.CharField(max_length=150)
    category = models.CharField(max_length=50, choices=[('LEGAL','Legal & Contracts'), ('TECH','Technical Specs'), ('FIN','Financial Records')])
    file = models.FileField(upload_to='vault_files/')
    file_size_kb = models.FloatField(default=0.0)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if self.file:
            self.file_size_kb = round(self.file.size / 1024, 2)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title

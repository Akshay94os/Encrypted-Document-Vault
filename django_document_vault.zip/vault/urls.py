from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='vault_home'),
    path('delete/<int:pk>/', views.delete_doc, name='delete_doc'),
]

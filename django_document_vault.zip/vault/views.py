from django.shortcuts import render, redirect, get_object_or_404
from .models import Document

def index(request):
    if request.method == 'POST' and request.FILES.get('file'):
        title = request.POST.get('title')
        category = request.POST.get('category')
        file = request.FILES.get('file')
        Document.objects.create(title=title, category=category, file=file)
        return redirect('vault_home')

    docs = Document.objects.order_by('-uploaded_at')
    return render(request, 'vault/index.html', {'docs': docs})

def delete_doc(request, pk):
    doc = get_object_or_404(Document, id=pk)
    doc.file.delete()
    doc.delete()
    return redirect('vault_home')
